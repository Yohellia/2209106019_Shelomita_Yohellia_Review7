package com.example.flutter_review7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
